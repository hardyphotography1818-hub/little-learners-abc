/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "109aa4b0ee8685f498c056d6ce1720f8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8029ab8e51c22976f9782a859a728494"
  }, {
    "url": "pwa-192x192.png",
    "revision": "c42264134ffbc30e0e7b097d4cfbeb10"
  }, {
    "url": "index.html",
    "revision": "c9d7a1f91d025f4444d5290df6fd5c76"
  }, {
    "url": "icon.svg",
    "revision": "ad8f92079bb39e6611ba85f02a2c6fdd"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "80ce8de1ac12e3e63a06c7fc538987cd"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-pLMtdAwR.css",
    "revision": null
  }, {
    "url": "assets/index-BC9eezMV.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "80ce8de1ac12e3e63a06c7fc538987cd"
  }, {
    "url": "icon.svg",
    "revision": "ad8f92079bb39e6611ba85f02a2c6fdd"
  }, {
    "url": "pwa-192x192.png",
    "revision": "c42264134ffbc30e0e7b097d4cfbeb10"
  }, {
    "url": "pwa-512x512.png",
    "revision": "8029ab8e51c22976f9782a859a728494"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "109aa4b0ee8685f498c056d6ce1720f8"
  }, {
    "url": "manifest.webmanifest",
    "revision": "4ba64c4f9e470e495c2e364b11f5bf08"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
